unsigned long timer= 0; // Counter for TIMER0 overflows
unsigned char received_data; //stores BT data
int H_L; //for servo high and low
int K;  //Enable servo
int angle;
int servo;//check if servo open or close
int distance;
int l; // cheack start
int o;// check ir
int volt; //poten value

void mydelay_ms(unsigned int ms) {
    unsigned long delay = ms; // 1 overflow = 1 ms
    timer = 0;                 // Reset overflow counter
    while (timer < delay);
}



void Bluetooth_Init() {
    UART1_Init(9600); //transmission rate
    mydelay_ms(100); //delay to make sure it is ready
}


int dist(){

int d = 0;
T1CON = 0x10; // Use internal clock (accurate), no prescaler
mydelay_ms(10); //for stability

// Reset Timer1
TMR1H = 0;
TMR1L = 0;

    PORTC = PORTC | 0b00010000; // Trigger HIGH
    mydelay_ms(1);               // 1 ms delay
    PORTC = PORTC & 0b11101111; // Trigger LOW

    while (!(PORTC & 0b00100000)); //wait for echo to start


    T1CON = T1CON | 0b00000001; // Start Timer


    while (PORTC & 0b00100000); //wait for echo to end


    T1CON = T1CON & 0b11111110; // Stop Timer

    d = (TMR1L | (TMR1H << 8)); // Read Timer1 value
    d = d / 58.82;           // Convert time to distance (cm)
    mydelay_ms(10);
    T1CON = 0x01; //reanable TMR1 for future use
    return d;
}

void Forward(){
PORTB=PORTB & 0b11110000;
PORTB=PORTB | 0b00000101; //set forward pins
}

void Right(){
PORTB=PORTB & 0b11110000;
PORTB=PORTB | 0b00000110; // backwards direction
}

void Backward(){
PORTB=PORTB & 0b11110000;
PORTB=PORTB | 0b00001010;
}

void Left(){
PORTB=PORTB & 0b11110000; //make sure theyre stopped
PORTB=PORTB | 0b00001001;
}
void stop(){
PORTB=PORTB & 0b11110000; //stop all motors
}

void ATD_init(){
      ADCON0=0x41;           // ADC ON, Channel 0, Fosc/16== 500KHz, Dont Go
      ADCON1=0xCE;           // RA0 Analog, others are Digital
}
int ATD_read(){
      ADCON0=ADCON0 | 0x04;  // Start GO/DONE bit is 1
      while(ADCON0&0x04);    // wait until Finish
      return (ADRESH<<8)|ADRESL; //result is 10 bits
}
void CCPPWM_init(){                  // Configure CCP2 at 2ms
        T2CON = 0x07;                    // Enable Timer2 at Fosc/4 with 1:16 prescaler (8 uS percount 2000uS to count 250 counts)
        CCP2CON = 0x0C;                  // Enable PWM for CCP2
        PR2 = 250;                       // 250 counts = 8uS *250 = 2ms period
        CCPR2L = 125;                    // Buffer where we are specifying the pulse width (duty cycle)
}

void Speed(int p){
       p = (((p>>2)*250)/255);
       CCPR2L = p;                  // PWM from RC1
}

void interrupt(void){

 if(INTCON & 0x04){                                 // TMR0 overflow every 1 ms

 if(!(PORTD&0B00000001)){ //LOW = IR object detected
 timer++;                   //accurate
             PORTD=PORTD|0b00000100; //LED ON
             o=1; //IR flag raised, used in main
             }else{
              PORTD=PORTD&0b11111011; //Turn off LED
             o=0; //update flag
             }

         INTCON = INTCON & 0xFB; //clear interrupt flag
         TMR0 = 248;             // Reload TIMER0 to maintain precise timing

     }

       if(PIR1 & 0x04){ //compare mode
       if(K==1){                                           // CCP1 interrupt, servo enabled
             if(H_L){
                       CCPR1H = angle >> 8; //set high phase duration
                       CCPR1L = angle;
                       H_L = 0;                      //Low for next phase
                       CCP1CON = 0x09;              // compare mode, clear output on match
                       TMR1H = 0; //TMR1 Reset
                       TMR1L = 0;
             }
             else{                                          //low
                       CCPR1H = (40000 - angle) >> 8;       // 40000 counts correspond to 20ms
                       CCPR1L = (40000 - angle);
                       CCP1CON = 0x08;             // compare mode, set output on match
                       H_L = 1;                     //next time High
                       TMR1H = 0;
                       TMR1L = 0;
             }

             PIR1 = PIR1&0xFB; }else{ //clear interrupt flag

              PIR1 = PIR1&0xFB;
             }
       }


 }



void main() {
 TRISA= 0b00000001;
 TRISC = 0b10100000;
 TRISB = 0b00000000;
 TRISD=0b00000001;

 PORTB=0X00;
 PORTC=0X00;
 PORTD=0X00;

 Bluetooth_Init();

TMR1H = 0;
TMR1L = 0;
H_L = 1;                // start high
CCP1CON = 0x08;        // Compare mode, set output on match
T1CON = 0x01; //enable TMR0
// Enable interrupts
INTCON = 0b11100000;         // Enable GIE and peripheral interrupts and TIMER0 interrupts
PIE1 = PIE1|0x04;      // Enable CCP1 interrupts
CCPR1H = 2000>>8;      // Value preset in a program to compare the TMR1H value to - 1ms
CCPR1L = 2000;         // Value preset in a program to compare the TMR1L value to


OPTION_REG = 0x87; //  Set prescaler to 1:256, TIMER0 as timer
TMR0 = 248;     // Preload value for ~1ms overflow

ATD_init();
CCPPWM_init();
//inialize servo
K=0; //disable servo
servo=0; //start in closed position

K=1; //enable servo
angle=2700; //set servo angle
K=0; //diable after setup


while(1){

while(UART1_Data_Ready()) {
volt=ATD_read();
Speed(volt); //adjust speeed
            received_data = UART1_Read();
             if(received_data=='F'){
              Forward();
             }
             else if(received_data=='B'){
             distance=dist();
             mydelay_ms(100);
             if(distance<20){
             Right();
             }else{backward();}
             }
             else if(received_data=='R'){
               Right();
             }
             else if(received_data=='L'){
               Left();
             }
             else if(received_data=='X'){ //release object
             if(servo==1){ //servo is open

                K=1; //enable control for PWM
               angle=2700; // release angle
               mydelay_ms(100);
               K=0;
               servo=0;
               }else{servo=servo;}
             }
             else if(received_data=='x'){ //grab object
             if(servo==0){
                if(o==1){
               K=1;
               angle=1000;
               mydelay_ms(100);
               K=0;
               servo=1;}else{K=0;}
               }else{servo=servo;}
             }
             else{
              stop();
             }



        }


}

}